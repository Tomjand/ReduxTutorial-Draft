import React from "react";
import LessonDescription from "./LessonDescription";

export default class App extends React.Component {
  render() {
    return (
      <div>
        <LessonDescription />
      </div>
    );
  }
}
