import React from "react";

const LessonDescription = () => {
  return (
    <div>
      <h1>moj kurs Redux ver2 lekcja 02 </h1>
      <p>wszystko synchroniczne totalne wprowadzenie</p>
    </div>
  );
};

export default LessonDescription;
